import './assets/index.ts-DDTMGEIQ.js';
